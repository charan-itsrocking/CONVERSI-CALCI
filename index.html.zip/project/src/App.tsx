import React, { useState } from 'react';
import ConversionForm from './components/ConversionForm';
import PremiumFeatures from './components/PremiumFeatures';
import FinancialCalculator from './components/calculators/FinancialCalculator';
import { Calculator, Sparkles, Calculator as CalcIcon, TrendingUp } from 'lucide-react';

type CalculatorType = 'digital' | 'financial';

function App() {
  const [activeCalculator, setActiveCalculator] = useState<CalculatorType>('digital');

  return (
    <div className="min-h-screen bg-gradient-professional overflow-hidden">
      <div className="relative w-full">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNiIgZmlsbD0icmdiYSgyNTUsIDI1NSwgMjU1LCAwLjEpIi8+PC9nPjwvc3ZnPg==')] opacity-5"></div>

        <div className="relative z-10 flex flex-col items-center p-6">
          <header className="w-full max-w-4xl text-center mb-8">
            <div className="inline-flex items-center gap-3 mb-4">
              <Calculator className="w-12 h-12 text-blue-100 animate-float" />
              <div>
                <h1 className="text-5xl font-bold text-white">
                  DigiCalci
                  <span className="text-yellow-300 animate-pulse ml-2">by CHARAN</span>
                </h1>
                <div className="flex items-center justify-center gap-2 mt-2">
                  <Sparkles className="w-5 h-5 text-blue-200" />
                  <p className="text-xl text-blue-100 font-light">
                    Your Ultimate Calculation Companion
                  </p>
                  <Sparkles className="w-5 h-5 text-blue-200" />
                </div>
              </div>
            </div>
          </header>

          <div className="w-full max-w-4xl mb-8">
            <div className="flex justify-center gap-4 mb-8">
              <button
                onClick={() => setActiveCalculator('digital')}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                  activeCalculator === 'digital'
                    ? 'bg-white text-blue-600 shadow-lg scale-105'
                    : 'bg-blue-800/50 text-white hover:bg-blue-700/50'
                }`}
              >
                <CalcIcon className="w-5 h-5" />
                Digital Logic Calculator
              </button>
              <button
                onClick={() => setActiveCalculator('financial')}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                  activeCalculator === 'financial'
                    ? 'bg-white text-blue-600 shadow-lg scale-105'
                    : 'bg-blue-800/50 text-white hover:bg-blue-700/50'
                }`}
              >
                <TrendingUp className="w-5 h-5" />
                Financial Calculator
              </button>
            </div>
          </div>
          
          <main className="w-full flex flex-col items-center gap-8">
            {activeCalculator === 'digital' ? (
              <>
                <ConversionForm />
                <PremiumFeatures />
              </>
            ) : (
              <FinancialCalculator />
            )}
          </main>

          <footer className="mt-12 text-center text-blue-100/80">
            <p className="text-sm">© 2024 DigiCalci by CHARAN. All rights reserved.</p>
            <p className="text-xs mt-1">Engineered with precision by CHARAN</p>
          </footer>
        </div>
      </div>
    </div>
  );
}

export default App;