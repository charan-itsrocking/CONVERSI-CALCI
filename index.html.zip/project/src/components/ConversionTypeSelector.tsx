import React from 'react';
import type { ConversionType } from '../types';

interface Props {
  conversionType: ConversionType;
  onChange: (type: ConversionType) => void;
}

export default function ConversionTypeSelector({ conversionType, onChange }: Props) {
  return (
    <div className="flex gap-4">
      <button
        onClick={() => onChange('number')}
        className={`flex-1 py-2 px-4 rounded-lg ${
          conversionType === 'number'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-100 text-gray-700'
        }`}
      >
        Number Systems
      </button>
      <button
        onClick={() => onChange('code')}
        className={`flex-1 py-2 px-4 rounded-lg ${
          conversionType === 'code'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-100 text-gray-700'
        }`}
      >
        Code Systems
      </button>
    </div>
  );
}