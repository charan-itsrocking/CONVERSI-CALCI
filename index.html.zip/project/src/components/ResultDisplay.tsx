import React, { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, Copy, Info } from 'lucide-react';

interface Props {
  result: string;
  error: string;
}

export default function ResultDisplay({ result, error }: Props) {
  const [show, setShow] = useState(false);
  const [copied, setCopied] = useState(false);
  const [bounce, setBounce] = useState(false);

  useEffect(() => {
    if (error || result) {
      setShow(true);
      setBounce(true);
      const bounceTimer = setTimeout(() => setBounce(false), 500);
      return () => clearTimeout(bounceTimer);
    }
  }, [error, result]);

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (error) {
    return (
      <div 
        className={`transform transition-all duration-500 ease-out
          ${show ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}
          ${bounce ? 'animate-shake' : ''}`}
      >
        <div className="p-4 bg-red-50/90 backdrop-blur border-l-4 border-red-500 rounded-lg shadow-lg">
          <div className="flex items-start">
            <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 animate-pulse" />
            <div className="ml-3 flex-1">
              <h3 className="text-sm font-medium text-red-800">Invalid Input</h3>
              <div className="mt-1">
                <p className="text-sm text-red-700">{error}</p>
                <div className="mt-2 p-2 bg-red-100/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Info className="w-4 h-4 text-red-600" />
                    <span className="text-xs text-red-700 font-medium">Tips:</span>
                  </div>
                  <ul className="mt-1 text-xs text-red-700 list-disc list-inside space-y-1">
                    {error.includes('binary') && (
                      <li>Binary numbers can only contain 0s and 1s</li>
                    )}
                    {error.includes('decimal') && (
                      <li>Decimal numbers must be positive integers</li>
                    )}
                    {error.includes('hexadecimal') && (
                      <li>Hexadecimal numbers can only contain 0-9 and A-F</li>
                    )}
                    {error.includes('octal') && (
                      <li>Octal numbers can only contain digits 0-7</li>
                    )}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!result) {
    return null;
  }

  return (
    <div 
      className={`transform transition-all duration-500 ease-out
        ${show ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}
        ${bounce ? 'animate-bounce-small' : ''}`}
    >
      <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50/90 backdrop-blur border-l-4 border-green-500 rounded-lg shadow-lg">
        <div className="flex items-start">
          <CheckCircle2 className="w-5 h-5 text-green-500 mt-0.5 animate-pulse" />
          <div className="ml-3 flex-1">
            <h3 className="text-sm font-medium text-green-800">Conversion Result</h3>
            <div className="mt-2 relative">
              <div className="font-mono text-lg break-all bg-white/80 backdrop-blur p-3 rounded border border-green-200 pr-12 hover-lift">
                {result}
              </div>
              <button
                onClick={handleCopy}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-500 hover:text-gray-700 
                         transition-colors hover:bg-gray-100/50 rounded-full"
                title="Copy to clipboard"
              >
                <Copy className="w-5 h-5" />
                {copied && (
                  <span className="absolute -top-8 right-0 text-xs bg-black text-white px-2 py-1 rounded animate-fade-in">
                    Copied!
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}