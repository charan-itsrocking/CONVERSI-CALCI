import React, { useState } from 'react';
import { Calculator, ArrowRight, History } from 'lucide-react';
import ConversionTypeSelector from './ConversionTypeSelector';
import ConversionInputs from './ConversionInputs';
import ResultDisplay from './ResultDisplay';
import ConversionHistory from './ConversionHistory';
import { performConversion } from '../lib/conversions/conversionHandler';
import { generateConversionSteps } from '../lib/conversions/conversionSteps';
import type { ConversionType, SystemType, ConversionRecord } from '../types';

export default function ConversionForm() {
  const [input, setInput] = useState('');
  const [fromSystem, setFromSystem] = useState<SystemType>('binary');
  const [toSystem, setToSystem] = useState<SystemType>('decimal');
  const [conversionType, setConversionType] = useState<ConversionType>('number');
  const [result, setResult] = useState('');
  const [error, setError] = useState('');
  const [history, setHistory] = useState<ConversionRecord[]>([]);

  const handleConvert = () => {
    try {
      setError('');
      const convertedResult = performConversion(input, fromSystem, toSystem, conversionType);
      setResult(convertedResult);
      
      const steps = generateConversionSteps(input, fromSystem, toSystem, convertedResult);
      const record: ConversionRecord = {
        fromSystem,
        toSystem,
        input,
        result: convertedResult,
        timestamp: Date.now(),
        steps
      };
      
      setHistory(prev => [record, ...prev]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setResult('');
    }
  };

  return (
    <div className="w-full max-w-2xl space-y-8">
      <div className="glass-effect rounded-xl professional-shadow overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="flex items-center gap-3">
            <Calculator className="w-8 h-8 text-blue-600 animate-float" />
            <h2 className="text-2xl font-bold text-gray-800">
              Convert Numbers & Codes
            </h2>
          </div>

          <div className="space-y-6">
            <ConversionTypeSelector
              conversionType={conversionType}
              onChange={setConversionType}
            />

            <ConversionInputs
              input={input}
              fromSystem={fromSystem}
              toSystem={toSystem}
              conversionType={conversionType}
              onInputChange={setInput}
              onFromSystemChange={setFromSystem}
              onToSystemChange={setToSystem}
            />

            <button
              onClick={handleConvert}
              className="w-full py-3 px-6 bg-gradient-accent text-white rounded-lg font-semibold 
                       hover:opacity-90 transform hover:scale-[1.02] active:scale-[0.98] 
                       transition-all duration-200 hover-lift"
            >
              <div className="flex items-center justify-center gap-2">
                <span>Convert</span>
                <ArrowRight className="w-5 h-5" />
              </div>
            </button>

            <ResultDisplay result={result} error={error} />
          </div>
        </div>
      </div>

      {history.length > 0 && (
        <div className="glass-effect rounded-xl professional-shadow overflow-hidden animate-slide-up">
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <History className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-800">
                Conversion History
              </h2>
            </div>
            <ConversionHistory history={history} />
          </div>
        </div>
      )}
    </div>
  );
}