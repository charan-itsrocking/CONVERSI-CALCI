import React from 'react';
import { History, ChevronDown, ChevronUp, Clock, ArrowRight, Calculator } from 'lucide-react';
import { ConversionRecord } from '../types';

interface Props {
  history: ConversionRecord[];
}

export default function ConversionHistory({ history }: Props) {
  const [expandedItems, setExpandedItems] = React.useState<Set<number>>(new Set());

  const toggleItem = (index: number) => {
    const newExpanded = new Set(expandedItems);
    if (expandedItems.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedItems(newExpanded);
  };

  if (history.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-2xl mt-8 bg-gradient-to-br from-white to-blue-50 rounded-xl shadow-lg p-6 animate-slide-up">
      <div className="flex items-center gap-3 mb-6">
        <History className="w-6 h-6 text-blue-600 animate-pulse" />
        <h2 className="text-2xl font-bold text-gray-800">Conversion History</h2>
      </div>

      <div className="space-y-4">
        {history.map((record, index) => (
          <div
            key={record.timestamp}
            className="border border-gray-200 rounded-lg overflow-hidden transition-all duration-300 hover:shadow-md bg-white"
          >
            <button
              onClick={() => toggleItem(index)}
              className="w-full p-4 flex items-center justify-between hover:bg-blue-50 transition-colors"
            >
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-blue-500" />
                    <span className="font-medium text-gray-700">
                      {record.fromSystem.toUpperCase()} 
                      <ArrowRight className="w-4 h-4 inline mx-1 text-blue-500" />
                      {record.toSystem.toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Clock className="w-4 h-4" />
                    {new Date(record.timestamp).toLocaleTimeString()}
                  </div>
                </div>
                <div className="mt-2 text-sm">
                  <span className="text-gray-600 font-mono bg-gray-100 px-2 py-1 rounded">
                    {record.input}
                  </span>
                  <ArrowRight className="w-4 h-4 inline mx-2 text-blue-500" />
                  <span className="text-blue-600 font-mono bg-blue-50 px-2 py-1 rounded">
                    {record.result}
                  </span>
                </div>
              </div>
              {expandedItems.has(index) ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>

            {expandedItems.has(index) && (
              <div className="p-4 bg-gradient-to-br from-blue-50 to-white border-t border-gray-200 animate-slide-down">
                <h4 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-sm">
                    ?
                  </span>
                  Solution Steps
                </h4>
                <ol className="space-y-3 text-gray-600">
                  {record.steps.map((step, stepIndex) => (
                    <li
                      key={stepIndex}
                      className="animate-fade-in flex items-start gap-3 p-2 rounded-lg hover:bg-blue-50 transition-colors"
                      style={{ animationDelay: `${stepIndex * 100}ms` }}
                    >
                      <span className="w-6 h-6 rounded-full bg-blue-100 flex-shrink-0 flex items-center justify-center text-blue-600 text-sm">
                        {stepIndex + 1}
                      </span>
                      <span className="flex-1">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}