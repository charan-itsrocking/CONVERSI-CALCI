import React from 'react';
import type { ConversionType, SystemType } from '../types';

interface Props {
  input: string;
  fromSystem: SystemType;
  toSystem: SystemType;
  conversionType: ConversionType;
  onInputChange: (value: string) => void;
  onFromSystemChange: (system: SystemType) => void;
  onToSystemChange: (system: SystemType) => void;
}

export default function ConversionInputs({
  input,
  fromSystem,
  toSystem,
  conversionType,
  onInputChange,
  onFromSystemChange,
  onToSystemChange,
}: Props) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Input Value
        </label>
        <input
          type="text"
          value={input}
          onChange={(e) => onInputChange(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Enter your number..."
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            From
          </label>
          <select
            value={fromSystem}
            onChange={(e) => onFromSystemChange(e.target.value as SystemType)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="binary">Binary</option>
            <option value="decimal">Decimal</option>
            <option value="octal">Octal</option>
            <option value="hexadecimal">Hexadecimal</option>
            {conversionType === 'code' && (
              <>
                <option value="bcd">BCD</option>
                <option value="gray">Gray Code</option>
              </>
            )}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            To
          </label>
          <select
            value={toSystem}
            onChange={(e) => onToSystemChange(e.target.value as SystemType)}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="decimal">Decimal</option>
            <option value="binary">Binary</option>
            <option value="octal">Octal</option>
            <option value="hexadecimal">Hexadecimal</option>
            {conversionType === 'code' && (
              <>
                <option value="bcd">BCD</option>
                <option value="gray">Gray Code</option>
                <option value="excess3">Excess-3</option>
              </>
            )}
          </select>
        </div>
      </div>
    </div>
  );
}