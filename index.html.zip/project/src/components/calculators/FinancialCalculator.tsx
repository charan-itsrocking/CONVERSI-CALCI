import React, { useState } from 'react';
import { Calculator, Percent, TrendingUp, DollarSign, History } from 'lucide-react';

type CalculationType = 'profit-loss' | 'interest' | 'discount' | 'tax';

interface CalculationResult {
  type: CalculationType;
  input: Record<string, number>;
  output: Record<string, number>;
  timestamp: number;
}

export default function FinancialCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>('profit-loss');
  const [history, setHistory] = useState<CalculationResult[]>([]);
  const [values, setValues] = useState<Record<string, number>>({});
  const [result, setResult] = useState<Record<string, number>>({});

  const calculateResult = () => {
    let newResult: Record<string, number> = {};
    
    switch (calculationType) {
      case 'profit-loss':
        const cp = values.costPrice || 0;
        const sp = values.sellingPrice || 0;
        const diff = sp - cp;
        const percentage = (diff / cp) * 100;
        newResult = {
          difference: diff,
          percentage: percentage,
          isProfit: diff > 0
        };
        break;

      case 'interest':
        const principal = values.principal || 0;
        const rate = values.rate || 0;
        const time = values.time || 0;
        const interest = (principal * rate * time) / 100;
        newResult = {
          interest: interest,
          total: principal + interest
        };
        break;

      case 'discount':
        const originalPrice = values.originalPrice || 0;
        const discountPercent = values.discountPercent || 0;
        const discountAmount = (originalPrice * discountPercent) / 100;
        newResult = {
          discountAmount: discountAmount,
          finalPrice: originalPrice - discountAmount
        };
        break;

      case 'tax':
        const baseAmount = values.baseAmount || 0;
        const taxRate = values.taxRate || 0;
        const taxAmount = (baseAmount * taxRate) / 100;
        newResult = {
          taxAmount: taxAmount,
          totalAmount: baseAmount + taxAmount
        };
        break;
    }

    setResult(newResult);
    setHistory(prev => [{
      type: calculationType,
      input: values,
      output: newResult,
      timestamp: Date.now()
    }, ...prev]);
  };

  const renderInputs = () => {
    switch (calculationType) {
      case 'profit-loss':
        return (
          <>
            <input
              type="number"
              placeholder="Cost Price"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, costPrice: parseFloat(e.target.value) })}
            />
            <input
              type="number"
              placeholder="Selling Price"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, sellingPrice: parseFloat(e.target.value) })}
            />
          </>
        );

      case 'interest':
        return (
          <>
            <input
              type="number"
              placeholder="Principal Amount"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, principal: parseFloat(e.target.value) })}
            />
            <input
              type="number"
              placeholder="Rate of Interest (%)"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, rate: parseFloat(e.target.value) })}
            />
            <input
              type="number"
              placeholder="Time (in years)"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, time: parseFloat(e.target.value) })}
            />
          </>
        );

      case 'discount':
        return (
          <>
            <input
              type="number"
              placeholder="Original Price"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, originalPrice: parseFloat(e.target.value) })}
            />
            <input
              type="number"
              placeholder="Discount Percentage"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, discountPercent: parseFloat(e.target.value) })}
            />
          </>
        );

      case 'tax':
        return (
          <>
            <input
              type="number"
              placeholder="Base Amount"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, baseAmount: parseFloat(e.target.value) })}
            />
            <input
              type="number"
              placeholder="Tax Rate (%)"
              className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500"
              onChange={e => setValues({ ...values, taxRate: parseFloat(e.target.value) })}
            />
          </>
        );
    }
  };

  const renderResult = () => {
    if (Object.keys(result).length === 0) return null;

    switch (calculationType) {
      case 'profit-loss':
        return (
          <div className="space-y-2">
            <p className="text-lg">
              {result.isProfit ? (
                <span className="text-green-600">Profit: ₹{Math.abs(result.difference)}</span>
              ) : (
                <span className="text-red-600">Loss: ₹{Math.abs(result.difference)}</span>
              )}
            </p>
            <p className="text-gray-600">
              Percentage: {Math.abs(result.percentage).toFixed(2)}%
            </p>
          </div>
        );

      case 'interest':
        return (
          <div className="space-y-2">
            <p className="text-lg">Interest Amount: ₹{result.interest.toFixed(2)}</p>
            <p className="text-gray-600">Total Amount: ₹{result.total.toFixed(2)}</p>
          </div>
        );

      case 'discount':
        return (
          <div className="space-y-2">
            <p className="text-lg">Discount Amount: ₹{result.discountAmount.toFixed(2)}</p>
            <p className="text-gray-600">Final Price: ₹{result.finalPrice.toFixed(2)}</p>
          </div>
        );

      case 'tax':
        return (
          <div className="space-y-2">
            <p className="text-lg">Tax Amount: ₹{result.taxAmount.toFixed(2)}</p>
            <p className="text-gray-600">Total Amount: ₹{result.totalAmount.toFixed(2)}</p>
          </div>
        );
    }
  };

  return (
    <div className="w-full max-w-2xl space-y-8">
      <div className="glass-effect rounded-xl professional-shadow overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="flex items-center gap-3">
            <TrendingUp className="w-8 h-8 text-blue-600 animate-float" />
            <h2 className="text-2xl font-bold text-gray-800">
              Financial Calculator
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => setCalculationType('profit-loss')}
              className={`p-3 rounded-lg flex flex-col items-center gap-2 transition-all ${
                calculationType === 'profit-loss'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <TrendingUp className="w-5 h-5" />
              <span className="text-sm">Profit/Loss</span>
            </button>
            <button
              onClick={() => setCalculationType('interest')}
              className={`p-3 rounded-lg flex flex-col items-center gap-2 transition-all ${
                calculationType === 'interest'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Percent className="w-5 h-5" />
              <span className="text-sm">Interest</span>
            </button>
            <button
              onClick={() => setCalculationType('discount')}
              className={`p-3 rounded-lg flex flex-col items-center gap-2 transition-all ${
                calculationType === 'discount'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <DollarSign className="w-5 h-5" />
              <span className="text-sm">Discount</span>
            </button>
            <button
              onClick={() => setCalculationType('tax')}
              className={`p-3 rounded-lg flex flex-col items-center gap-2 transition-all ${
                calculationType === 'tax'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Calculator className="w-5 h-5" />
              <span className="text-sm">Tax</span>
            </button>
          </div>

          <div className="space-y-4">
            {renderInputs()}
            
            <button
              onClick={calculateResult}
              className="w-full py-3 px-6 bg-gradient-accent text-white rounded-lg font-semibold 
                       hover:opacity-90 transform hover:scale-[1.02] active:scale-[0.98] 
                       transition-all duration-200 hover-lift"
            >
              Calculate
            </button>

            {renderResult() && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                {renderResult()}
              </div>
            )}
          </div>
        </div>
      </div>

      {history.length > 0 && (
        <div className="glass-effect rounded-xl professional-shadow overflow-hidden animate-slide-up">
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <History className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-800">
                Calculation History
              </h2>
            </div>
            <div className="space-y-4">
              {history.map((item, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-gray-600">
                      {new Date(item.timestamp).toLocaleTimeString()}
                    </span>
                    <span className="text-sm text-gray-400">•</span>
                    <span className="text-sm font-medium text-blue-600">
                      {item.type.replace('-', '/')}
                    </span>
                  </div>
                  {/* Render calculation details based on type */}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}