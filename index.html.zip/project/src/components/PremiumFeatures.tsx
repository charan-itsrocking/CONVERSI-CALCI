import React from 'react';
import { Crown, BookOpen, History, Zap } from 'lucide-react';

export default function PremiumFeatures() {
  return (
    <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-6 mt-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          Upgrade to Premium
        </h2>
        <p className="text-gray-600">
          Unlock advanced features and enhance your conversion experience
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-2">
            <Zap className="w-6 h-6 text-yellow-500" />
            <h3 className="font-semibold">Batch Conversions</h3>
          </div>
          <p className="text-gray-600 text-sm">
            Convert multiple values simultaneously
          </p>
        </div>

        <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-2">
            <History className="w-6 h-6 text-blue-500" />
            <h3 className="font-semibold">Conversion History</h3>
          </div>
          <p className="text-gray-600 text-sm">
            Access and export your conversion history
          </p>
        </div>

        <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="w-6 h-6 text-green-500" />
            <h3 className="font-semibold">Learning Resources</h3>
          </div>
          <p className="text-gray-600 text-sm">
            Access detailed tutorials and guides
          </p>
        </div>

        <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
          <div className="flex items-center gap-3 mb-2">
            <Crown className="w-6 h-6 text-purple-500" />
            <h3 className="font-semibold">Advanced Features</h3>
          </div>
          <p className="text-gray-600 text-sm">
            Custom themes and advanced conversions
          </p>
        </div>
      </div>

      <button 
        className="w-full mt-6 py-3 px-6 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg font-semibold hover:from-blue-600 hover:to-indigo-700 transition-colors"
        onClick={() => alert('Premium features coming soon!')}
      >
        Upgrade Now
      </button>
    </div>
  );
}