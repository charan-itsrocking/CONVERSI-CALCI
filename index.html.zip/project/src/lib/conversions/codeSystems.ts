// Code conversion utilities
export const codeSystems = {
  // Binary to Gray Code
  binToGray: (binary: string): string => {
    if (!/^[01]+$/.test(binary)) {
      throw new Error('Invalid binary number format. Binary numbers can only contain 0s and 1s.');
    }
    let gray = binary[0];
    for (let i = 1; i < binary.length; i++) {
      gray += (parseInt(binary[i]) ^ parseInt(binary[i-1])).toString();
    }
    return gray;
  },

  // Gray Code to Binary
  grayToBin: (gray: string): string => {
    if (!/^[01]+$/.test(gray)) {
      throw new Error('Invalid Gray code format. Gray code can only contain 0s and 1s.');
    }
    let binary = gray[0];
    for (let i = 1; i < gray.length; i++) {
      binary += (parseInt(binary[i-1]) ^ parseInt(gray[i])).toString();
    }
    return binary;
  },

  // Decimal to Gray Code
  decToGray: (decimal: string): string => {
    if (!/^\d+$/.test(decimal)) {
      throw new Error('Invalid decimal number format. Please enter a positive integer.');
    }
    const binary = parseInt(decimal).toString(2);
    return codeSystems.binToGray(binary);
  },

  // Gray Code to Decimal
  grayToDec: (gray: string): string => {
    if (!/^[01]+$/.test(gray)) {
      throw new Error('Invalid Gray code format. Gray code can only contain 0s and 1s.');
    }
    const binary = codeSystems.grayToBin(gray);
    return parseInt(binary, 2).toString();
  },

  // Binary to BCD
  binToBCD: (binary: string): string => {
    if (!/^[01]+$/.test(binary)) {
      throw new Error('Invalid binary number format. Binary numbers can only contain 0s and 1s.');
    }
    const decimal = parseInt(binary, 2);
    if (decimal > 9999) {
      throw new Error('BCD conversion supports numbers up to 9999 only.');
    }
    return decimal.toString().split('')
      .map(digit => parseInt(digit).toString(2).padStart(4, '0'))
      .join(' ');
  },

  // BCD to Binary
  BCDToBin: (bcd: string): string => {
    const bcdGroups = bcd.split(' ');
    if (!bcdGroups.every(group => /^[01]{4}$/.test(group))) {
      throw new Error('Invalid BCD format. Each group must be 4 bits.');
    }
    const decimal = bcdGroups
      .map(group => {
        const value = parseInt(group, 2);
        if (value > 9) {
          throw new Error('Invalid BCD digit. Each group must represent a decimal digit (0-9).');
        }
        return value.toString();
      })
      .join('');
    return parseInt(decimal).toString(2);
  },

  // Decimal to BCD
  decToBCD: (decimal: string): string => {
    if (!/^\d+$/.test(decimal) || parseInt(decimal) > 9999) {
      throw new Error('Invalid decimal number. Please enter a positive integer up to 9999.');
    }
    return decimal.split('')
      .map(digit => parseInt(digit).toString(2).padStart(4, '0'))
      .join(' ');
  },

  // BCD to Decimal
  BCDToDec: (bcd: string): string => {
    const bcdGroups = bcd.split(' ');
    if (!bcdGroups.every(group => /^[01]{4}$/.test(group))) {
      throw new Error('Invalid BCD format. Each group must be 4 bits.');
    }
    return bcdGroups
      .map(group => {
        const value = parseInt(group, 2);
        if (value > 9) {
          throw new Error('Invalid BCD digit. Each group must represent a decimal digit (0-9).');
        }
        return value.toString();
      })
      .join('');
  },

  // Decimal to Excess-3
  decToExcess3: (decimal: string): string => {
    if (!/^\d+$/.test(decimal) || parseInt(decimal) > 9999) {
      throw new Error('Invalid decimal number. Please enter a positive integer up to 9999.');
    }
    return decimal.split('')
      .map(digit => {
        const value = parseInt(digit) + 3;
        return value.toString(2).padStart(4, '0');
      })
      .join(' ');
  },

  // BCD to Excess-3
  BCDToExcess3: (bcd: string): string => {
    const bcdGroups = bcd.split(' ');
    if (!bcdGroups.every(group => /^[01]{4}$/.test(group))) {
      throw new Error('Invalid BCD format. Each group must be 4 bits.');
    }
    return bcdGroups
      .map(group => {
        const decimal = parseInt(group, 2);
        if (decimal > 9) {
          throw new Error('Invalid BCD digit. Each group must represent a decimal digit (0-9).');
        }
        return (decimal + 3).toString(2).padStart(4, '0');
      })
      .join(' ');
  },

  // Excess-3 to BCD
  excess3ToBCD: (excess3: string): string => {
    const excess3Groups = excess3.split(' ');
    if (!excess3Groups.every(group => /^[01]{4}$/.test(group))) {
      throw new Error('Invalid Excess-3 format. Each group must be 4 bits.');
    }
    return excess3Groups
      .map(group => {
        const decimal = parseInt(group, 2) - 3;
        if (decimal < 0 || decimal > 9) {
          throw new Error('Invalid Excess-3 digit. Each group must represent a decimal digit plus 3 (3-12).');
        }
        return decimal.toString(2).padStart(4, '0');
      })
      .join(' ');
  },

  // Excess-3 to Decimal
  excess3ToDec: (excess3: string): string => {
    const bcd = codeSystems.excess3ToBCD(excess3);
    return codeSystems.BCDToDec(bcd);
  }
};