// Number system conversion utilities
export const numberSystems = {
  // Binary to Decimal
  binToDec: (binary: string): number => {
    if (!/^[01]+$/.test(binary)) {
      throw new Error('Invalid binary number format. Binary numbers can only contain 0s and 1s.');
    }
    return parseInt(binary, 2);
  },

  // Decimal to Binary
  decToBin: (decimal: string): string => {
    const num = parseInt(decimal);
    if (isNaN(num) || num < 0 || !Number.isInteger(num)) {
      throw new Error('Invalid decimal number. Please enter a positive integer.');
    }
    return num.toString(2);
  },

  // Binary to Octal
  binToOct: (binary: string): string => {
    if (!/^[01]+$/.test(binary)) {
      throw new Error('Invalid binary number format. Binary numbers can only contain 0s and 1s.');
    }
    const decimal = parseInt(binary, 2);
    return decimal.toString(8);
  },

  // Binary to Hexadecimal
  binToHex: (binary: string): string => {
    if (!/^[01]+$/.test(binary)) {
      throw new Error('Invalid binary number format. Binary numbers can only contain 0s and 1s.');
    }
    const decimal = parseInt(binary, 2);
    return decimal.toString(16).toUpperCase();
  },

  // Custom base conversion
  convertBase: (number: string, fromBase: number, toBase: number): string => {
    // Input validation
    const validChars = {
      2: /^[01]+$/,
      8: /^[0-7]+$/,
      10: /^\d+$/,
      16: /^[0-9A-Fa-f]+$/
    };

    const regex = validChars[fromBase as keyof typeof validChars];
    if (!regex?.test(number)) {
      const baseNames = {
        2: 'Binary',
        8: 'Octal',
        10: 'Decimal',
        16: 'Hexadecimal'
      };
      throw new Error(`Invalid ${baseNames[fromBase as keyof typeof baseNames]} number format.`);
    }

    // Special handling for decimal to binary conversion
    if (fromBase === 10 && toBase === 2) {
      return numberSystems.decToBin(number);
    }

    const decimal = parseInt(number, fromBase);
    if (isNaN(decimal)) {
      throw new Error('Invalid number format for conversion.');
    }
    
    return decimal.toString(toBase).toUpperCase();
  }
};