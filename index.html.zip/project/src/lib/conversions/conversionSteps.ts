import type { SystemType } from '../../types';

export function generateConversionSteps(
  input: string,
  fromSystem: SystemType,
  toSystem: SystemType,
  result: string
): string[] {
  const steps: string[] = [];

  // Number system conversions
  if (['binary', 'decimal', 'octal', 'hexadecimal'].includes(fromSystem) &&
      ['binary', 'decimal', 'octal', 'hexadecimal'].includes(toSystem)) {
    if (fromSystem !== 'decimal') {
      const decimal = parseInt(input, getBase(fromSystem));
      steps.push(`Step 1: Convert ${fromSystem} number ${input} to decimal`);
      steps.push(`Method: Multiply each digit by its position value and sum`);
      
      const digits = input.split('').reverse();
      const calculations = digits.map((digit, i) => {
        const value = parseInt(digit, getBase(fromSystem)) * Math.pow(getBase(fromSystem), i);
        return `${digit} × ${getBase(fromSystem)}^${i} = ${value}`;
      });
      
      steps.push(...calculations);
      steps.push(`Sum: ${calculations.map(calc => calc.split(' = ')[1]).join(' + ')} = ${decimal}`);
      steps.push(`Therefore, ${input}${getSubscript(fromSystem)} = ${decimal}₁₀`);
    }

    if (toSystem !== 'decimal') {
      const decimal = fromSystem === 'decimal' ? parseInt(input) : parseInt(input, getBase(fromSystem));
      steps.push(`Step ${fromSystem === 'decimal' ? '1' : '2'}: Convert decimal ${decimal} to ${toSystem}`);
      steps.push(`Method: Repeatedly divide by ${getBase(toSystem)} and collect remainders in reverse`);
      
      let num = decimal;
      const divisions = [];
      while (num > 0) {
        const remainder = num % getBase(toSystem);
        divisions.push(`${num} ÷ ${getBase(toSystem)} = ${Math.floor(num / getBase(toSystem))} remainder ${remainder}`);
        num = Math.floor(num / getBase(toSystem));
      }
      
      steps.push(...divisions);
      steps.push(`Reading remainders from bottom to top: ${result}`);
      steps.push(`Therefore, ${decimal}₁₀ = ${result}${getSubscript(toSystem)}`);
    }
  }

  // Code system conversions
  if ((fromSystem === 'binary' || fromSystem === 'decimal') && toSystem === 'gray') {
    const binary = fromSystem === 'decimal' ? parseInt(input).toString(2) : input;
    steps.push('Gray Code Conversion Steps:');
    steps.push(`1. ${fromSystem === 'decimal' ? 'Convert decimal to binary first: ' + input + '₁₀ = ' + binary + '₂' : 'Start with binary number: ' + binary}`);
    steps.push('2. Keep the first bit as is');
    steps.push('3. For each subsequent bit:');
    steps.push('   - XOR it with the previous bit (1⊕1=0, 1⊕0=1, 0⊕1=1, 0⊕0=0)');
    
    const binaryDigits = binary.split('');
    const grayDigits = result.split('');
    const xorSteps = grayDigits.map((gray, i) => {
      if (i === 0) return `Position ${i}: Keep first bit: ${gray}`;
      return `Position ${i}: ${binaryDigits[i-1]} ⊕ ${binaryDigits[i]} = ${gray}`;
    });
    
    steps.push(...xorSteps);
    steps.push(`Final Gray code: ${result}`);
  }

  if ((fromSystem === 'decimal' || fromSystem === 'binary') && toSystem === 'bcd') {
    const decimal = fromSystem === 'binary' ? parseInt(input, 2).toString() : input;
    steps.push('BCD Conversion Steps:');
    steps.push(`1. ${fromSystem === 'binary' ? 'Convert binary to decimal first: ' + input + '₂ = ' + decimal : 'Start with decimal number: ' + decimal}`);
    steps.push('2. Convert each decimal digit to 4-bit binary:');
    
    const digits = decimal.split('');
    const bcdGroups = result.split(' ');
    const digitConversions = digits.map((digit, i) => 
      `   Digit ${digit} = ${parseInt(digit).toString(2).padStart(4, '0')} (BCD)`
    );
    
    steps.push(...digitConversions);
    steps.push(`Final BCD: ${result}`);
  }

  if (fromSystem === 'decimal' && toSystem === 'excess3') {
    steps.push('Decimal to Excess-3 Conversion Steps:');
    steps.push('For each decimal digit:');
    steps.push('1. Add 3 to the digit');
    steps.push('2. Convert result to 4-bit binary');
    
    const digits = input.split('');
    const excess3Groups = result.split(' ');
    
    const digitConversions = digits.map((digit, i) => [
      `Digit ${i + 1}: ${digit}`,
      `   Add 3: ${digit} + 3 = ${parseInt(digit) + 3}`,
      `   To binary: ${excess3Groups[i]}`
    ]).flat();
    
    steps.push(...digitConversions);
    steps.push(`Final Excess-3 code: ${result}`);
  }

  if (fromSystem === 'bcd' && toSystem === 'excess3') {
    const bcdGroups = input.split(' ');
    const excess3Groups = result.split(' ');
    
    steps.push('BCD to Excess-3 Conversion Steps:');
    steps.push('For each BCD group:');
    steps.push('1. Convert BCD to decimal');
    steps.push('2. Add 3 to the decimal value');
    steps.push('3. Convert result to 4-bit binary');
    
    const groupConversions = bcdGroups.map((bcd, i) => {
      const decimal = parseInt(bcd, 2);
      return [
        `Group ${i+1}: ${bcd} (BCD)`,
        `   Decimal value: ${decimal}`,
        `   Add 3: ${decimal} + 3 = ${decimal + 3}`,
        `   To binary: ${excess3Groups[i]} (Excess-3)`
      ];
    }).flat();
    
    steps.push(...groupConversions);
    steps.push(`Final Excess-3 code: ${result}`);
  }

  return steps;
}

function getBase(system: SystemType): number {
  switch (system) {
    case 'binary': return 2;
    case 'decimal': return 10;
    case 'octal': return 8;
    case 'hexadecimal': return 16;
    default: return 10;
  }
}

function getSubscript(system: SystemType): string {
  switch (system) {
    case 'binary': return '₂';
    case 'decimal': return '₁₀';
    case 'octal': return '₈';
    case 'hexadecimal': return '₁₆';
    default: return '';
  }
}