import { numberSystems } from './numberSystems';
import { codeSystems } from './codeSystems';
import type { ConversionType, SystemType } from '../../types';

export function performConversion(
  input: string,
  fromSystem: SystemType,
  toSystem: SystemType,
  conversionType: ConversionType
): string {
  // Validate input is not empty
  if (!input.trim()) {
    throw new Error('Please enter a value to convert.');
  }

  if (conversionType === 'number') {
    return handleNumberConversion(input, fromSystem, toSystem);
  } else {
    return handleCodeConversion(input, fromSystem, toSystem);
  }
}

function handleNumberConversion(
  input: string,
  fromSystem: SystemType,
  toSystem: SystemType
): string {
  // Special handling for decimal to binary
  if (fromSystem === 'decimal' && toSystem === 'binary') {
    return numberSystems.decToBin(input);
  }

  // Convert between any bases
  const fromBase = getBase(fromSystem);
  const toBase = getBase(toSystem);
  return numberSystems.convertBase(input.trim(), fromBase, toBase);
}

function handleCodeConversion(
  input: string,
  fromSystem: SystemType,
  toSystem: SystemType
): string {
  const trimmedInput = input.trim();
  
  switch(fromSystem) {
    case 'binary':
      switch(toSystem) {
        case 'gray': return codeSystems.binToGray(trimmedInput);
        case 'bcd': return codeSystems.binToBCD(trimmedInput);
        default: throw new Error('Unsupported conversion');
      }
    
    case 'decimal':
      switch(toSystem) {
        case 'gray': return codeSystems.decToGray(trimmedInput);
        case 'bcd': return codeSystems.decToBCD(trimmedInput);
        case 'excess3': return codeSystems.decToExcess3(trimmedInput);
        default: throw new Error('Unsupported conversion');
      }
    
    case 'gray':
      switch(toSystem) {
        case 'binary': return codeSystems.grayToBin(trimmedInput);
        case 'decimal': return codeSystems.grayToDec(trimmedInput);
        default: throw new Error('Unsupported conversion');
      }
    
    case 'bcd':
      switch(toSystem) {
        case 'binary': return codeSystems.BCDToBin(trimmedInput);
        case 'decimal': return codeSystems.BCDToDec(trimmedInput);
        case 'excess3': return codeSystems.BCDToExcess3(trimmedInput);
        default: throw new Error('Unsupported conversion');
      }
    
    case 'excess3':
      switch(toSystem) {
        case 'bcd': return codeSystems.excess3ToBCD(trimmedInput);
        case 'decimal': return codeSystems.excess3ToDec(trimmedInput);
        default: throw new Error('Unsupported conversion');
      }
    
    default:
      throw new Error('Unsupported conversion');
  }
}

function getBase(system: SystemType): number {
  switch (system) {
    case 'binary':
      return 2;
    case 'decimal':
      return 10;
    case 'octal':
      return 8;
    case 'hexadecimal':
      return 16;
    default:
      throw new Error('Unsupported number system');
  }
}