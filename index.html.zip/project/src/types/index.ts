export type ConversionType = 'number' | 'code';

export type SystemType = 
  | 'binary'
  | 'decimal'
  | 'octal'
  | 'hexadecimal'
  | 'bcd'
  | 'gray'
  | 'excess3';

export interface ConversionRecord {
  fromSystem: SystemType;
  toSystem: SystemType;
  input: string;
  result: string;
  timestamp: number;
  steps: string[];
}